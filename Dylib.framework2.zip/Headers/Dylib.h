//
//  Dylib.h
//  Dylib
//
//  Created by GeekRRK on 15/3/25.
//  Copyright (c) 2015年 GeekRRK. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Dylib.
FOUNDATION_EXPORT double DylibVersionNumber;

//! Project version string for Dylib.
FOUNDATION_EXPORT const unsigned char DylibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Dylib/PublicHeader.h>

#import <Dylib/Test.h>